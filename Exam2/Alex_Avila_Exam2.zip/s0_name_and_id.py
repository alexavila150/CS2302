class Section0:
    student_last_name = "Avila"
    student_first_name = "Alex"
    utep_id = "80631370"
    secret = "zipfiles"

    @staticmethod
    def i_earned_extra_credit():

        return False  # Return True if and only if you earned extra-credit (correcting Diego or
        # participating in Padilla's experiment)
