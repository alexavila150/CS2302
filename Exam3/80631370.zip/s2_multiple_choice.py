class MultipleChoiceSection:

    @staticmethod
    def get_problem_6_answer():

        return 0  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_7_answer():

        return 3  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_8_answer():

        return 1  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_9_answer():

        return 2  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_10_answer():

        return 2  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_11_answer():

        return 2  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_12_answer():

        return 6  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_13_answer():

        return 2  # If you think the answer is option n, return n

    @staticmethod
    def get_problem_14_answer():

        return 4  # If you think the answer is option n, return n
